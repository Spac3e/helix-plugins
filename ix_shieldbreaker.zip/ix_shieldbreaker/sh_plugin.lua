PLUGIN.name = "Shield Breaker"
PLUGIN.author = "-Spac3"
PLUGIN.description = "Clockwork port to helix"

ix.config.add(
	"forcefieldBrakeTime",
	4,
	"How long does it take to break the forcefield.",
	nil,
	{
		category = PLUGIN.name,
		data = {min = 0, max = 60}
	}
)

ix.config.add(
	"forcefieldBrakeStrip",
	true,
	"Get the forcefield braker after use.",
	nil,
	{
		category = PLUGIN.name,
		data = {min = 0, max = 60}
	}
)
